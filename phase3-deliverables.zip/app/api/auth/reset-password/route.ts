// app/api/auth/reset-password/route.ts
// Request or fulfill a password reset with 6-digit verification code, rate limiting, and hashed secrets.

import { NextRequest, NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { db } from "@/lib/db/client";
import { sendEmail } from "@/lib/email/email-service";
import { APP_NAME } from "@/config/constants";
import { z } from "zod";
import { generateSecureOtp, hashSecretToken, verifySecretToken } from "@/lib/utils/crypto";
import {
  passwordResetRequestLimiter,
  passwordResetVerifyLimiter,
  getClientIp,
} from "@/lib/utils/rate-limit";

const RequestResetSchema = z.object({
  action: z.literal("request"),
  email: z.string().trim().toLowerCase().email("Please provide a valid email address"),
});

const VerifyAndResetSchema = z.object({
  action: z.literal("reset"),
  email: z.string().trim().toLowerCase().email("Please provide a valid email address"),
  code: z.string().trim().length(6, "Reset code must be 6 digits"),
  newPassword: z
    .string()
    .min(8, "Password must be at least 8 characters long")
    .max(100, "Password is too long")
    .regex(/[A-Za-z]/, "Password must contain at least one letter")
    .regex(/[0-9]/, "Password must contain at least one number"),
});

export async function POST(req: NextRequest) {
  try {
    const ip = getClientIp(req);
    const body = await req.json();

    if (body.action === "request") {
      const parsed = RequestResetSchema.safeParse(body);
      if (!parsed.success) {
        return NextResponse.json({ error: parsed.error.errors[0]?.message || "Invalid input" }, { status: 400 });
      }

      const { email } = parsed.data;

      // Rate limit password reset requests (Issue 20 & 22)
      const ipCheck = await passwordResetRequestLimiter.check(`ip:${ip}`);
      const emailCheck = await passwordResetRequestLimiter.check(`email:${email}`);
      if (!ipCheck.success || !emailCheck.success) {
        return NextResponse.json(
          { error: "Too many password reset requests. Please wait 15 minutes before trying again." },
          { status: 429 }
        );
      }

      const user = await db.user.findUnique({
        where: { email },
      });

      // Avoid account enumeration: always return success
      if (!user) {
        return NextResponse.json({
          success: true,
          message: "If an account exists with this email, a 6-digit reset code has been sent.",
        });
      }

      // Generate cryptographically secure reset code (Issue 16)
      const resetCode = generateSecureOtp();
      const expires = new Date(Date.now() + 15 * 60 * 1000); // 15 mins

      // Clean existing reset tokens for this email
      await db.verificationToken.deleteMany({
        where: { identifier: `reset:${email}` },
      });

      // Store hashed reset token (Issue 19)
      await db.verificationToken.create({
        data: {
          identifier: `reset:${email}`,
          token: hashSecretToken(resetCode),
          expires,
          attempts: 0,
        },
      });

      // Build email
      const appBaseUrl = (
        process.env.NEXT_PUBLIC_APP_URL ||
        (process.env.VERCEL_URL ? `https://${process.env.VERCEL_URL}` : "") ||
        "https://softshowcase.vercel.app"
      ).replace(/\/$/, "");
      const logoUrl = `${appBaseUrl}/logo.png`;

      // Send email asynchronously without blocking the response (Issue 24)
      sendEmail({
        to: email,
        subject: `Your ${APP_NAME} Password Reset Code: ${resetCode}`,
        html: `
          <!DOCTYPE html>
          <html lang="en">
          <head><meta charset="utf-8"></head>
          <body style="margin: 0; padding: 0; background-color: #F8FAFA; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
            <table width="100%" border="0" cellspacing="0" cellpadding="0" style="background-color: #F8FAFA; padding: 40px 16px;">
              <tr>
                <td align="center">
                  <table width="100%" border="0" cellspacing="0" cellpadding="0" style="max-width: 560px; background-color: #FFFFFF; border: 1px solid #D9E2E4; border-radius: 20px; overflow: hidden; box-shadow: 0 4px 20px rgba(16, 33, 36, 0.04);">
                    <tr>
                      <td style="padding: 28px 40px 22px; border-bottom: 1px solid #F3F7F7; background: linear-gradient(180deg, #F8FAFA 0%, #FFFFFF 100%);">
                        <table width="100%" border="0" cellspacing="0" cellpadding="0">
                          <tr>
                            <td valign="middle">
                              <a href="${appBaseUrl}" target="_blank" style="text-decoration: none; display: inline-block;">
                                <img src="${logoUrl}" alt="Soft Showcase" height="32" style="height: 32px; width: auto; max-width: 170px; display: block; border: 0;" />
                              </a>
                            </td>
                            <td align="right" valign="middle">
                              <span style="display: inline-block; background-color: #FEE4E2; color: #D92D20; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; padding: 5px 12px; border-radius: 8px;">
                                Security
                              </span>
                            </td>
                          </tr>
                        </table>
                      </td>
                    </tr>
                    <tr>
                      <td style="padding: 36px 40px 28px;">
                        <h1 style="color: #102124; font-size: 22px; font-weight: 800; margin: 0 0 16px;">Password Reset Request</h1>
                        <p style="font-size: 15px; line-height: 1.6; color: #526267; margin: 0 0 20px;">
                          Hello <strong style="color: #102124;">${user.name || "there"}</strong>,
                        </p>
                        <p style="font-size: 15px; line-height: 1.6; color: #526267; margin: 0 0 28px;">
                          We received a request to reset your password for your <strong>${APP_NAME}</strong> account. Use the following 6-digit reset code:
                        </p>
                        <div style="background-color: #F8FAFA; border: 1.5px dashed #155761; border-radius: 16px; padding: 26px 20px; text-align: center; margin: 0 0 28px;">
                          <div style="font-size: 11px; text-transform: uppercase; letter-spacing: 1.5px; font-weight: 700; color: #526267; margin-bottom: 8px;">
                            Your 6-Digit Reset Code
                          </div>
                          <div style="font-size: 38px; font-family: 'SFMono-Regular', Consolas, Menlo, Monaco, monospace; font-weight: 800; letter-spacing: 10px; color: #155761; padding-left: 10px;">
                            ${resetCode}
                          </div>
                          <div style="font-size: 12px; font-weight: 500; color: #526267; margin-top: 8px;">
                            Expires in <strong style="color: #102124;">15 minutes</strong>
                          </div>
                        </div>
                        <p style="font-size: 13px; line-height: 1.5; color: #8A979B; margin: 0;">
                          If you did not request a password reset, you can safely ignore this email. Your current password remains completely unchanged.
                        </p>
                      </td>
                    </tr>
                    <tr>
                      <td style="padding: 24px 40px; background-color: #F8FAFA; border-top: 1px solid #D9E2E4; text-align: center;">
                        <p style="margin: 0; font-size: 11px; color: #8A979B;">
                          © ${new Date().getFullYear()} Soft Showcase. All rights reserved.
                        </p>
                      </td>
                    </tr>
                  </table>
                </td>
              </tr>
            </table>
          </body>
          </html>
        `,
        text: `Your ${APP_NAME} password reset code is: ${resetCode}. Valid for 15 minutes.`,
      }).catch((emailErr) => {
        console.error("[Reset Password] Background email error:", emailErr);
      });

      return NextResponse.json({
        success: true,
        message: "If an account exists with this email, a 6-digit reset code has been sent.",
      });
    }

    if (body.action === "reset") {
      const parsed = VerifyAndResetSchema.safeParse(body);
      if (!parsed.success) {
        return NextResponse.json({ error: parsed.error.errors[0]?.message || "Invalid input" }, { status: 400 });
      }

      const { email, code, newPassword } = parsed.data;

      // Rate limit reset verification attempts (Issue 20)
      const verifyCheck = await passwordResetVerifyLimiter.check(`verify:${email}`);
      const ipCheck = await passwordResetVerifyLimiter.check(`ip:${ip}`);
      if (!verifyCheck.success || !ipCheck.success) {
        // Do NOT delete tokens on rate limit hit (M5) - prevents attacker lockout abuse
        const resetTime = Math.max(verifyCheck.reset, ipCheck.reset);
        const retryAfter = Math.max(1, Math.ceil((resetTime - Date.now()) / 1000));
        return NextResponse.json(
          { error: "Too many failed reset attempts. Please wait before trying again." },
          { status: 429, headers: { "Retry-After": String(retryAfter) } }
        );
      }

      const tokenRecords = await db.verificationToken.findMany({
        where: {
          identifier: `reset:${email}`,
        },
      });

      const activeRecord = tokenRecords.find((rec) => new Date() <= rec.expires);

      if (!activeRecord) {
        return NextResponse.json(
          { error: "Reset code has expired or was not found. Please request a new code." },
          { status: 400 }
        );
      }

      if (activeRecord.attempts >= 5) {
        await db.verificationToken.deleteMany({
          where: { identifier: `reset:${email}` },
        });
        return NextResponse.json(
          { error: "Too many failed attempts. This reset code has been invalidated. Please request a new code." },
          { status: 400 }
        );
      }

      const isValid = verifySecretToken(code, activeRecord.token);

      if (!isValid) {
        await db.verificationToken.updateMany({
          where: { identifier: `reset:${email}` },
          data: { attempts: { increment: 1 } },
        }).catch(() => null);

        const remaining = Math.max(0, 4 - activeRecord.attempts);
        return NextResponse.json(
          { error: `Invalid reset code. ${remaining} attempt${remaining === 1 ? "" : "s"} remaining.` },
          { status: 400 }
        );
      }

      const user = await db.user.findUnique({
        where: { email },
      });

      if (!user) {
        return NextResponse.json({ error: "User account not found." }, { status: 404 });
      }

      const passwordHash = await bcrypt.hash(newPassword, 10);

      await db.$transaction(async (tx) => {
        await tx.user.update({
          where: { email },
          data: {
            passwordHash,
            tokenVersion: { increment: 1 },
            emailVerified: user.emailVerified || new Date(),
          },
        });

        // Revoke all active sessions (Issue 58 / M6)
        await tx.session.deleteMany({
          where: { userId: user.id },
        });

        // Clear tokens
        await tx.verificationToken.deleteMany({
          where: { identifier: `reset:${email}` },
        });

        await tx.auditLog.create({
          data: {
            userId: user.id,
            action: "PASSWORD_RESET_COMPLETED",
            entityType: "User",
            entityId: user.id,
            details: { email },
          },
        }).catch(() => null);
      });

      await passwordResetVerifyLimiter.reset(`verify:${email}`);

      return NextResponse.json({
        success: true,
        message: "Password reset successfully. You can now sign in with your new password.",
      });
    }

    return NextResponse.json({ error: "Invalid action." }, { status: 400 });
  } catch (error) {
    console.error("[Reset Password] Error:", error);
    return NextResponse.json(
      { error: "An unexpected error occurred. Please try again later." },
      { status: 500 }
    );
  }
}
