// components/layout/NavbarClient.tsx
"use client";

import * as React from "react";
import Link from "next/link";
import Image from "next/image";
import { usePathname } from "next/navigation";
import { signOut } from "next-auth/react";
import { Menu, X, ArrowUpRight, LayoutDashboard, MessageSquare, LogOut, KeyRound, User, Sparkles, Layers } from "lucide-react";
import { Button, buttonVariants } from "@/components/ui/button";
import { UserNavDropdown } from "@/components/layout/UserNavDropdown";
import { CartNavButton } from "@/components/cart/CartNavButton";

interface NavbarClientProps {
  user?: {
    id?: string;
    name?: string | null;
    email?: string | null;
    image?: string | null;
    isAdmin?: boolean;
    role?: "customer" | "solution_partner" | "admin";
    partnerStatus?: "pending" | "approved" | "rejected" | "suspended" | "deactivated" | null;
    partnerId?: string | null;
  } | null;
  signOutAction: () => Promise<void>;
}

export function NavbarClient({ user, signOutAction }: NavbarClientProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);
  const pathname = usePathname();

  const handleSignOut = async () => {
    try {
      await signOut({ callbackUrl: "/" });
    } catch {
      if (signOutAction) await signOutAction();
    }
  };

  const isPartner =
    user?.role === "solution_partner" ||
    user?.partnerStatus === "approved" ||
    Boolean(user?.partnerId);

  const navLinks = [
    { label: "Browse Projects", href: "/projects" },
    { label: "Categories", href: "/#categories" },
    {
      label: isPartner ? "Partner Portal" : "Partners",
      href: isPartner ? "/partner" : "/become-a-partner",
    },
    { label: "How It Works", href: "/#how-it-works" },
    { label: "Why Us", href: "/#why-us" },
  ];

  const isActive = (href: string) => {
    if (href.startsWith("/#")) return false;
    if (href === "/become-a-partner") {
      return (
        pathname === "/become-a-partner" ||
        pathname === "/partner-registration" ||
        pathname === "/partner/register" ||
        pathname === "/partner/status"
      );
    }
    if (href === "/partner") {
      return (
        pathname.startsWith("/partner") &&
        pathname !== "/partner/register" &&
        pathname !== "/partner/status" &&
        pathname !== "/partner-registration"
      );
    }
    return pathname === href;
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b border-[#D9E2E4] bg-white/95 backdrop-blur-md shadow-[0_1px_4px_rgba(16,33,36,0.02)]">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8 relative">
        {/* Brand: Real Soft Showcase Logo */}
        <div className="flex items-center shrink-0">
          <Link
            href="/"
            className="flex items-center group py-1"
          >
            <Image
              src="/logo.png"
              alt="Soft Showcase"
              width={140}
              height={29}
              className="h-7 w-auto object-contain"
              priority
            />
          </Link>
        </div>

        {/* Desktop Navigation Links */}
        <nav className="hidden md:flex items-center gap-1 xl:gap-2">
          {navLinks.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors whitespace-nowrap ${
                isActive(link.href)
                  ? "bg-[#F3F7F7] text-[#155761] font-semibold"
                  : "text-[#526267] hover:text-[#102124] hover:bg-[#F3F7F7]"
              }`}
            >
              {link.label}
            </Link>
          ))}
        </nav>

        {/* Desktop Auth & CTAs */}
        <div className="hidden md:flex items-center gap-2.5 shrink-0">
          {user && <CartNavButton />}

          {user ? (
            <div className="flex items-center gap-2">
              {user.isAdmin && (
                <Link
                  href="/admin"
                  className={buttonVariants({
                    variant: "outline",
                    size: "sm",
                    className: "gap-1.5 text-xs text-[#155761] font-semibold border-[#155761]/30 hover:bg-[#F3F7F7]",
                  })}
                >
                  <LayoutDashboard className="w-3.5 h-3.5 text-[#155761]" />
                  Admin Panel
                </Link>
              )}

              <UserNavDropdown
                user={{
                  id: user.id,
                  name: user.name,
                  email: user.email,
                  image: user.image,
                  isAdmin: user.isAdmin,
                  role: user.role,
                  partnerStatus: user.partnerStatus,
                  partnerId: user.partnerId,
                }}
                onSignOut={handleSignOut}
              />
            </div>
          ) : (
            <div className="flex items-center gap-2.5">
              <Link
                href="/login"
                className={buttonVariants({
                  variant: "outline",
                  size: "sm",
                  className: "text-xs sm:text-sm font-medium px-4",
                })}
              >
                Sign In
              </Link>
              <Link
                href="/login?callbackUrl=/custom-project"
                className={buttonVariants({
                  variant: "primary",
                  size: "sm",
                  className: "text-xs sm:text-sm gap-1 shadow-xs font-semibold",
                })}
              >
                Request Software
                <ArrowUpRight className="w-3.5 h-3.5" />
              </Link>
            </div>
          )}
        </div>

        {/* Mobile Menu & Cart Button */}
        <div className="flex items-center gap-1.5 md:hidden">
          {user && <CartNavButton />}
          <button
            type="button"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 text-[#526267] hover:text-[#102124] focus:outline-none"
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden border-b border-[#D9E2E4] bg-white px-4 pt-2 pb-6 space-y-4">
          <nav className="flex flex-col space-y-2">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className={`px-3 py-2 rounded-lg text-sm font-medium ${
                  isActive(link.href)
                    ? "bg-[#F3F7F7] text-[#155761] font-semibold"
                    : "text-[#526267] hover:bg-[#F3F7F7] hover:text-[#102124]"
                }`}
              >
                {link.label}
              </Link>
            ))}
          </nav>

          <div className="pt-4 border-t border-[#D9E2E4]">
            {user ? (
              <div className="space-y-3">
                <div className="flex items-center gap-3 px-3 py-2">
                  {user.image ? (
                    <div className="relative w-9 h-9 rounded-full overflow-hidden border border-[#D9E2E4] shrink-0">
                      <Image
                        src={user.image}
                        alt={user.name || "User"}
                        fill
                        sizes="36px"
                        className="object-cover"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                  ) : (
                    <div className="w-9 h-9 rounded-full bg-[#F3F7F7] border border-[#D9E2E4] text-[#155761] flex items-center justify-center text-sm font-semibold">
                      {user.name?.[0]?.toUpperCase() || "U"}
                    </div>
                  )}
                  <div>
                    <div className="text-sm font-semibold text-[#102124]">
                      {user.name || "Authenticated User"}
                    </div>
                    <div className="text-xs text-[#526267] truncate">{user.email}</div>
                  </div>
                </div>

                {user.isAdmin && (
                  <>
                    <Link
                      href="/admin"
                      onClick={() => setMobileMenuOpen(false)}
                      className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-semibold text-[#155761] bg-[#F3F7F7]"
                    >
                      <LayoutDashboard className="w-4 h-4 text-[#155761]" />
                      Admin Dashboard
                    </Link>
                    <Link
                      href="/admin/profile"
                      onClick={() => setMobileMenuOpen(false)}
                      className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium text-[#526267] hover:bg-[#F3F7F7] hover:text-[#155761]"
                    >
                      <User className="w-4 h-4 text-[#155761]" />
                      Admin Profile
                    </Link>
                    <Link
                      href="/admin/profile?tab=password"
                      onClick={() => setMobileMenuOpen(false)}
                      className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium text-[#526267] hover:bg-[#F3F7F7] hover:text-[#155761]"
                    >
                      <KeyRound className="w-4 h-4 text-[#2F7D78]" />
                      Change Admin Password
                    </Link>
                  </>
                )}

                {!user.isAdmin && (
                  <Link
                    href="/profile"
                    onClick={() => setMobileMenuOpen(false)}
                    className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium text-[#526267] hover:bg-[#F3F7F7] hover:text-[#155761]"
                  >
                    <User className="w-4 h-4 text-[#526267]" />
                    Profile Settings
                  </Link>
                )}

                <Link
                  href="/my-inquiries"
                  onClick={() => setMobileMenuOpen(false)}
                  className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium text-[#526267] hover:bg-[#F3F7F7] hover:text-[#155761]"
                >
                  <MessageSquare className="w-4 h-4 text-[#526267]" />
                  My Inquiries
                </Link>

                <Link
                  href="/my-requests"
                  onClick={() => setMobileMenuOpen(false)}
                  className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium text-[#526267] hover:bg-[#F3F7F7] hover:text-[#155761]"
                >
                  <ArrowUpRight className="w-4 h-4 text-[#526267]" />
                  Custom Requests
                </Link>

                {isPartner && (
                  <Link
                    href="/partner"
                    onClick={() => setMobileMenuOpen(false)}
                    className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-semibold text-[#2F7D78] bg-[#DDF4EC]/40 hover:bg-[#DDF4EC]/70"
                  >
                    <Layers className="w-4 h-4 text-[#2F7D78]" />
                    Partner Portal
                  </Link>
                )}

                <div className="pt-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleSignOut}
                    className="w-full gap-2 text-xs"
                  >
                    <LogOut className="w-4 h-4" />
                    Sign Out
                  </Button>
                </div>
              </div>
            ) : (
              <div className="flex flex-col gap-2.5">
                <Link
                  href="/login"
                  onClick={() => setMobileMenuOpen(false)}
                  className={buttonVariants({
                    variant: "outline",
                    size: "md",
                    className: "w-full text-sm font-medium",
                  })}
                >
                  Sign In
                </Link>
                <Link
                  href="/login?callbackUrl=/custom-project"
                  onClick={() => setMobileMenuOpen(false)}
                  className={buttonVariants({
                    variant: "primary",
                    size: "md",
                    className: "w-full text-sm font-semibold gap-1.5",
                  })}
                >
                  Request Custom Software
                  <ArrowUpRight className="w-4 h-4" />
                </Link>
                <div className="pt-2 text-center border-t border-[#D9E2E4]/60">
                  <Link
                    href="/partner-registration"
                    onClick={() => setMobileMenuOpen(false)}
                    className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#155761] hover:underline py-1"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-[#2F7D78]" />
                    <span>Register as a Solution Partner</span>
                  </Link>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
