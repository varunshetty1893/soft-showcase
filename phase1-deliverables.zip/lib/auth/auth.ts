// lib/auth/auth.ts
// NextAuth v5 (Auth.js) configuration for Soft Showcase.
// - Providers: Google OAuth + Email/Password (Credentials)
// - Session strategy: JWT (supports both Credentials and OAuth)
// - Database: PrismaAdapter for OAuth accounts, users, and tokens
// - isAdmin is read from the users table and propagated to the session.

import NextAuth, { CredentialsSignin } from "next-auth";
import Google from "next-auth/providers/google";
import Credentials from "next-auth/providers/credentials";
import { PrismaAdapter } from "@auth/prisma-adapter";
import bcrypt from "bcryptjs";
import { db } from "@/lib/db/client";
import { LoginSchema } from "@/lib/validation/auth.schema";
import { authLoginLimiter, getRequestIp } from "@/lib/utils/rate-limit";
import { getEnv } from "@/lib/config/env";
import { bootstrapAdminOnVerification } from "@/lib/auth/admin-bootstrap";
import { getSafeCallbackUrl } from "@/lib/utils/safe-redirect";

export class LoginRateLimitError extends CredentialsSignin {
  code = "TOO_MANY_ATTEMPTS";
}

export class EmailNotVerifiedError extends CredentialsSignin {
  code = "EMAIL_NOT_VERIFIED";
}

if (!process.env.AUTH_URL && !process.env.NEXTAUTH_URL) {
  const envUrl =
    process.env.APP_URL ||
    process.env.NEXT_PUBLIC_APP_URL ||
    (process.env.VERCEL_URL ? `https://${process.env.VERCEL_URL}` : undefined);
  if (envUrl) {
    process.env.AUTH_URL = envUrl;
    process.env.NEXTAUTH_URL = envUrl;
  }
}

const authSecret = getEnv().AUTH_SECRET;

export const { handlers, auth, signIn, signOut } = NextAuth({
  secret: authSecret,
  trustHost: true,

  // ── Adapter ──────────────────────────────────────────────────────────────
  adapter: PrismaAdapter(db),

  // ── Providers ────────────────────────────────────────────────────────────
  providers: [
    ...(process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET
      ? [
          Google({
            clientId: process.env.GOOGLE_CLIENT_ID,
            clientSecret: process.env.GOOGLE_CLIENT_SECRET,
            allowDangerousEmailAccountLinking: false,
          }),
        ]
      : []),
    Credentials({
      name: "credentials",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials, request) {
        const parsed = LoginSchema.safeParse(credentials);
        if (!parsed.success) {
          console.warn("[Auth] Invalid login credentials format");
          return null;
        }

        const { email, password } = parsed.data;
        const normalizedEmail = email.trim().toLowerCase();

        // ── TASK 2: Login Brute-Force Rate Limiting (by IP and by email) ───────
        // Max 5 attempts per 15 minutes window
        const ip = await getRequestIp(request as Request);
        const ipKey = `ip:${ip}`;
        const emailKey = `email:${normalizedEmail}`;

        const ipCheck = await authLoginLimiter.check(ipKey);
        const emailCheck = await authLoginLimiter.check(emailKey);

        if (!ipCheck.success || !emailCheck.success) {
          console.warn(`[Auth] Credentials login rate limit exceeded (IP: ${ip})`);
          throw new LoginRateLimitError();
        }

        const user = await db.user.findUnique({
          where: { email: normalizedEmail },
        });

        if (!user || !user.passwordHash) {
          console.warn("[Auth] Invalid login attempt (user not found or no password)");
          return null;
        }

        const isPasswordValid = await bcrypt.compare(password, user.passwordHash);
        if (!isPasswordValid) {
          console.warn("[Auth] Invalid login attempt (password mismatch)");
          return null;
        }

        if (!user.emailVerified) {
          console.warn("[Auth] User email not verified");
          throw new EmailNotVerifiedError();
        }

        // Reset rate limiter on successful authentication
        await authLoginLimiter.reset(ipKey);
        await authLoginLimiter.reset(emailKey);

        const userRole = (user as { role?: "admin" | "customer" | "solution_partner" }).role;
        return {
          id: user.id,
          name: user.name,
          email: user.email,
          image: user.image,
          isAdmin: user.isAdmin,
          role: userRole || (user.isAdmin ? "admin" : "customer"),
          passwordHash: user.passwordHash,
        };
      },
    }),
  ],

  // ── Session (JWT strategy required for Credentials provider) ─────────────
  session: {
    strategy: "jwt",
    maxAge: 30 * 24 * 60 * 60, // 30 days
  },

  // ── Pages ─────────────────────────────────────────────────────────────────
  pages: {
    signIn: "/login",
    error: "/login",
  },

  // ── Callbacks ─────────────────────────────────────────────────────────────
  callbacks: {
    async signIn({ user, account, profile }) {
      // 1. Google OAuth security validation
      if (account?.provider === "google") {
        const isGoogleVerified = (profile as { email_verified?: boolean })?.email_verified;
        if (!isGoogleVerified) {
          console.warn(`[Auth] Blocked Google login: unverified Google email (${user.email})`);
          return false;
        }

        if (user.email) {
          const normalizedEmail = user.email.toLowerCase().trim();
          const existingUser = await db.user.findUnique({
            where: { email: normalizedEmail },
            include: { accounts: true },
          });

          if (existingUser) {
            // If existing user has a credentials password set and no linked Google account,
            // prevent silent account takeover. Require user to log in with password.
            const hasGoogleAccount = existingUser.accounts.some(
              (acc) => acc.provider === "google"
            );
            if (existingUser.passwordHash && !hasGoogleAccount) {
              console.warn(
                `[Auth] Blocked OAuth account takeover for ${normalizedEmail}. Password account exists.`
              );
              return "/login?error=OAuthAccountNotLinked";
            }

            // Auto-mark email as verified if they successfully sign in with verified Google
            if (!existingUser.emailVerified) {
              await db.user.update({
                where: { id: existingUser.id },
                data: { emailVerified: new Date() },
              });
            }

            // Run verified-email admin bootstrap hook
            await bootstrapAdminOnVerification(existingUser.id, normalizedEmail);
          }
        }
      }

      return true;
    },

    async jwt({ token, user }) {
      if (user) {
        token.id = user.id;
        token.email = user.email;
        token.isAdmin = (user as { isAdmin?: boolean }).isAdmin ?? false;
        token.role = (user as { role?: string }).role || (token.isAdmin ? "admin" : "customer");
        token.pwdHash = (user as { passwordHash?: string | null }).passwordHash
          ? (user as { passwordHash?: string | null }).passwordHash!.substring(0, 12)
          : "";
        token.lastChecked = Date.now();
      }

      // Keep user info, role and partner status up-to-date with 60-second caching to avoid DB lag on every click
      const now = Date.now();
      const lastChecked = (token.lastChecked as number) || 0;
      const shouldRefreshFromDb = Boolean(user) || (now - lastChecked > 60_000);

      if (token.id && shouldRefreshFromDb) {
        token.lastChecked = now;
        try {
          const dbUser = await db.user.findUnique({
            where: { id: token.id as string },
            select: { id: true, isAdmin: true, email: true, role: true, passwordHash: true },
          });

          if (!dbUser) {
            return {};
          }

          // Invalidate session if password was changed (Issue 58)
          const currentPwdHash = dbUser.passwordHash ? dbUser.passwordHash.substring(0, 12) : "";
          if (token.pwdHash && currentPwdHash && token.pwdHash !== currentPwdHash) {
            return {};
          }

          // Trusts ONLY DB-backed flag carried in database user record
          token.isAdmin = Boolean(dbUser.isAdmin);
          token.role = token.isAdmin ? "admin" : (dbUser.role || "customer");

            // Look up partner profile strictly by stable user relationship (userId)
            let partnerProfile = await db.projectProvider.findFirst({
              where: { userId: dbUser.id },
              select: { id: true, applicationStatus: true },
            }).catch(() => null);

            // One-time fallback: If legacy unlinked record exists for email, associate it
            if (!partnerProfile && dbUser.email) {
              const unlinked = await db.projectProvider.findFirst({
                where: { email: dbUser.email, userId: null },
                select: { id: true, applicationStatus: true },
              }).catch(() => null);
              if (unlinked) {
                await db.projectProvider.update({
                  where: { id: unlinked.id },
                  data: { userId: dbUser.id },
                }).catch(() => null);
                partnerProfile = unlinked;
              }
            }

            if (partnerProfile) {
              token.partnerId = partnerProfile.id;
              token.partnerStatus = partnerProfile.applicationStatus;
              if (token.role !== "admin") {
                token.role = "solution_partner";
              }
            } else {
              token.partnerId = null;
              token.partnerStatus = null;
            }
        } catch (e) {
          console.warn("[Auth] Failed to refresh token from db:", e);
        }
      }

      return token;
    },

    async session({ session, token }) {
      if (!token?.id) {
        return null as any;
      }
      if (session.user) {
        session.user.id = token.id as string;
        session.user.isAdmin = (token.isAdmin as boolean) ?? false;
        session.user.role = (token.role as "customer" | "solution_partner" | "admin") || (token.isAdmin ? "admin" : "customer");
        session.user.partnerStatus = (token.partnerStatus as "pending" | "approved" | "rejected" | "suspended" | "deactivated" | null) ?? null;
        session.user.partnerId = (token.partnerId as string | null) ?? null;
      }
      return session;
    },

    async redirect({ url, baseUrl }) {
      try {
        const baseOrigin = new URL(baseUrl).origin;
        if (url.startsWith("/")) {
          const safe = getSafeCallbackUrl(url, "/", baseOrigin);
          return `${baseOrigin}${safe}`;
        }
        const parsed = new URL(url);
        if (parsed.origin.toLowerCase() === baseOrigin.toLowerCase()) {
          const safe = getSafeCallbackUrl(parsed.pathname + parsed.search + parsed.hash, "/", baseOrigin);
          return `${baseOrigin}${safe}`;
        }
      } catch {
        // Fall back to baseUrl on any error
      }
      return baseUrl;
    },
  },
});
